package com.example.quiz_provis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
